//
//  DashBoardView.swift
//  BookMySlot_Interviewer
//
//  Created by admin on 15/02/25.
//
import SwiftUI
import CoreData

struct DashboardView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        entity: InterviewSlot.entity(),
        sortDescriptors: [NSSortDescriptor(keyPath: \InterviewSlot.date, ascending: true)]
    ) private var slots: FetchedResults<InterviewSlot>

    @State private var selectedSlot: InterviewSlot?
    @State private var showEditView = false
    @State private var showAddSlotView = false
    @Binding var isUserLoggedIn: Bool

    var body: some View {
        NavigationView {
            VStack {
                Text("Interview Slots")
                    .font(.largeTitle)
                    .bold()
                    .padding()

                List {
                    ForEach(slots, id: \.self) { slot in
                        VStack(alignment: .leading) {
                            Text("Date: \(formattedDate(slot.date))")
                                .font(.headline)
                            Text("Time: \(slot.fromTime ?? "N/A") - \(slot.uptoTime ?? "N/A")")
                                .foregroundColor(.gray)
                            Text("Interviewer: \(slot.interviewerName ?? "Not Assigned")")
                                .foregroundColor(.blue)
                            Text("Subject: \(slot.subject ?? "N/A")")
                                .foregroundColor(.purple)
                            Text("Status: \(slot.status ?? "Unknown")")
                                .foregroundColor(statusColor(slot.status ?? "Unknown"))
                        }
                        .padding()
                        .swipeActions {
                            Button {
                                selectedSlot = slot
                                showEditView.toggle()
                            } label: {
                                Label("Edit", systemImage: "pencil")
                            }
                            .tint(.blue)

                            Button(role: .destructive) {
                                deleteSlot(slot)
                            } label: {
                                Label("Delete", systemImage: "trash")
                            }
                        }
                    }
                }

                Spacer()

                Button(action: { showAddSlotView.toggle() }) {
                    Text("Add Slot")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding()
            }
            .sheet(isPresented: $showAddSlotView) {
                AddSlotView()
            }
            .sheet(item: $selectedSlot) { slot in
                EditSlotView(slot: slot)
            }
            .navigationBarItems(
                leading: Button(action: logout) {
                    Text("Logout")
                        .foregroundColor(.red)
                },
                trailing: EditButton()
            )
        }
    }

    private func deleteSlot(_ slot: InterviewSlot) {
        withAnimation {
            viewContext.delete(slot)
            do {
                try viewContext.save()
            } catch {
                print("Error deleting slot: \(error.localizedDescription)")
            }
        }
    }

    private func formattedDate(_ date: Date?) -> String {
        guard let date = date else { return "N/A" }
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }

    private func statusColor(_ status: String) -> Color {
        switch status {
        case "Available": return .green
        case "Booked": return .orange
        case "Completed": return .gray
        default: return .black
        }
    }

    private func logout() {
        isUserLoggedIn = false  
    }
}
