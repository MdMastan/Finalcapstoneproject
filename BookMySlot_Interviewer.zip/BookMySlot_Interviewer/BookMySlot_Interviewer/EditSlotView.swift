//
//  EditSlotView.swift
//  BookMySlot_Interviewer
//
//  Created by admin on 15/02/25.
//

import SwiftUI
import CoreData

struct EditSlotView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.presentationMode) var presentationMode

    @ObservedObject var slot: InterviewSlot

    var body: some View {
        NavigationView {
            VStack {
                Form {
                    Section(header: Text("Select Date")) {
                        DatePicker("Date", selection: Binding(
                            get: { slot.date ?? Date() },
                            set: { slot.date = $0 }
                        ), displayedComponents: .date)
                    }

                    Section(header: Text("Time")) {
                        HStack {
                            Text("From:")
                            TextField("Start Time", text: Binding(
                                get: { slot.fromTime ?? "" },
                                set: { slot.fromTime = $0 }
                            ))
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        }

                        HStack {
                            Text("To:")
                            TextField("End Time", text: Binding(
                                get: { slot.uptoTime ?? "" },
                                set: { slot.uptoTime = $0 }
                            ))
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        }
                    }

                    Section(header: Text("Interviewer")) {
                        TextField("Name", text: Binding(
                            get: { slot.interviewerName ?? "" },
                            set: { slot.interviewerName = $0 }
                        ))
                    }

                    Section(header: Text("Subject")) {
                        TextField("Subject", text: Binding(
                            get: { slot.subject ?? "" },
                            set: { slot.subject = $0 }
                        ))
                    }

                    Section(header: Text("Status")) {
                        Picker("Status", selection: Binding(
                            get: { slot.status ?? "Available" },
                            set: { slot.status = $0 }
                        )) {
                            Text("Available").tag("Available")
                            Text("Booked").tag("Booked")
                            Text("Completed").tag("Completed")
                        }
                        .pickerStyle(SegmentedPickerStyle())
                    }
                }

                
                HStack {
                
                    Button("Cancel") {
                        presentationMode.wrappedValue.dismiss()
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(8)

                    
                    Button("Delete") {
                        deleteSlot()
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.red)
                    .foregroundColor(.white)
                    .cornerRadius(8)

                    
                    Button("Save Changes") {
                        saveChanges()
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
                }
                .padding()
            }
            .navigationTitle("Edit Slot")
        }
    }

    
    private func deleteSlot() {
        withAnimation {
            viewContext.delete(slot)
            do {
                try viewContext.save()
                presentationMode.wrappedValue.dismiss() 
            } catch {
                print("Error deleting slot: \(error.localizedDescription)")
            }
        }
    }

    private func saveChanges() {
        do {
            try viewContext.save()
            presentationMode.wrappedValue.dismiss()
        } catch {
            print("Error saving slot: \(error.localizedDescription)")
        }
    }
}
