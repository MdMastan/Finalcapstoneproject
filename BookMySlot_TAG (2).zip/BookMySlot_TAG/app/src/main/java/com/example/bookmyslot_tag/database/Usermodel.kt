package com.example.bookmyslot_tag.database

data class UserModel(
    val username: String,
    val password: String
)
